Buenos G4 handout
=================

Changes from Buenos 1.1.2:

  + We have solved G1 and G2 (changes in `proc/syscall.c`, `proc/process.h`,
    `proc/process.c`, and `init/main.c`), including some tests.
  + We have included a userland library in `tests/lib.h` and `tests/lib.c`.
