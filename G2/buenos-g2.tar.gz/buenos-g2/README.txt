Buenos G2 handout
=================

Changes from Buenos 1.12: We have inserted code stubs in `proc/process.c` and
`proc/process.h`, and we have programmed a poor G1 pseudo-solution in
`proc/syscall.c`.

Please write nice code.
