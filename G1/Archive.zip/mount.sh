#!/bin/bash
sudo mount -t vboxsf -o uid=arkimedes,gid=$(id -g) buenos-gate /home/arkimedes/test
